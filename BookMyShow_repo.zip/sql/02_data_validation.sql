\echo '--- orphan shows (event / venue)'
SELECT (SELECT COUNT(*) FROM shows s LEFT JOIN events e ON s.event_id=e.event_id WHERE e.event_id IS NULL) AS invalid_show_events,
       (SELECT COUNT(*) FROM shows s LEFT JOIN venues v ON s.venue_id=v.venue_id WHERE v.venue_id IS NULL) AS invalid_show_venues;
\echo '--- duplicate booking_id'
SELECT COUNT(*) FROM (SELECT booking_id FROM bookings GROUP BY 1 HAVING COUNT(*)>1) d;
\echo '--- missing values in bookings'
SELECT COUNT(*) FILTER (WHERE customer_id IS NULL) c, COUNT(*) FILTER (WHERE show_id IS NULL) s, COUNT(*) FILTER (WHERE booking_datetime IS NULL) d, COUNT(*) FILTER (WHERE total_amount IS NULL) a, COUNT(*) FILTER (WHERE booking_status IS NULL) st FROM bookings;
\echo '--- invalid seats / amount'
SELECT COUNT(*) FROM bookings WHERE seats_booked<=0 OR total_amount<0;
\echo '--- booking status'
SELECT booking_status, COUNT(*) n, ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER(),2) pct FROM bookings GROUP BY 1 ORDER BY 2 DESC;
\echo '--- payment modes'
SELECT payment_mode, COUNT(*) n FROM bookings GROUP BY 1 ORDER BY 2 DESC;
\echo '--- invalid ages / ratings'
SELECT (SELECT COUNT(*) FROM customers WHERE age<0 OR age>100) bad_age, (SELECT COUNT(*) FROM ratings WHERE rating NOT BETWEEN 1 AND 5) bad_rating;
\echo '--- null profile'
SELECT (SELECT COUNT(*) FROM events WHERE critic_rating IS NULL) null_critic_rating, (SELECT COUNT(*) FROM events WHERE language IS NULL) null_language, (SELECT COUNT(*) FROM customers WHERE age IS NULL) null_age, (SELECT COUNT(*) FROM customers WHERE gender IS NULL) null_gender, (SELECT COUNT(*) FROM customers WHERE name IS NULL) null_name;
\echo '--- date coverage'
SELECT MIN(booking_datetime)::date first_booking, MAX(booking_datetime)::date last_booking, (SELECT MIN(show_date) FROM shows) first_show, (SELECT MAX(show_date) FROM shows) last_show FROM bookings;
\echo '--- bookings made AFTER show date (data quality)'
SELECT COUNT(*) FROM bookings b JOIN shows s USING(show_id) WHERE s.show_date < b.booking_datetime::date;
\echo '--- seats booked > capacity per show (Booked only)'
SELECT COUNT(*) FROM (SELECT s.show_id FROM shows s JOIN bookings b USING(show_id) WHERE b.booking_status='Booked' GROUP BY s.show_id, s.capacity HAVING SUM(b.seats_booked) > s.capacity) x;
\echo '--- duplicate venue names'
SELECT venue_name, city, COUNT(*) FROM venues GROUP BY 1,2 HAVING COUNT(*)>1;
\echo '--- gender values'
SELECT gender, COUNT(*) FROM customers GROUP BY 1 ORDER BY 2 DESC;
\echo '--- membership tiers, preferred categories'
SELECT membership_tier, COUNT(*) FROM customers GROUP BY 1 ORDER BY 2 DESC;
SELECT preferred_category, COUNT(*) FROM customers GROUP BY 1 ORDER BY 2 DESC;
\echo '--- amount sanity: total_amount vs seats*base_price (Booked)'
SELECT COUNT(*) total, COUNT(*) FILTER (WHERE b.total_amount = b.seats_booked*s.base_price) exact_match, COUNT(*) FILTER (WHERE b.total_amount > b.seats_booked*s.base_price) above_base, COUNT(*) FILTER (WHERE b.total_amount < b.seats_booked*s.base_price) below_base FROM bookings b JOIN shows s USING(show_id);
