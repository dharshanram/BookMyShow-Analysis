-- Q20. BOOKING LEAD-TIME ANALYSIS
-- Analyze how many days in advance customers book tickets
-- and compare booking volume and revenue across categories.

SELECT
    CASE
        WHEN s.show_date - b.booking_datetime::DATE = 0
            THEN 'Same Day'
        WHEN s.show_date - b.booking_datetime::DATE BETWEEN 1 AND 3
            THEN '1-3 Days'
        WHEN s.show_date - b.booking_datetime::DATE BETWEEN 4 AND 7
            THEN '4-7 Days'
        WHEN s.show_date - b.booking_datetime::DATE BETWEEN 8 AND 15
            THEN '8-15 Days'
        ELSE 'More Than 15 Days'
    END AS booking_lead_time,
    COUNT(b.booking_id) AS total_bookings,
    SUM(b.seats_booked) AS total_seats_booked,
    SUM(b.total_amount) AS total_revenue
FROM bookings b
JOIN shows s
    ON b.show_id = s.show_id
WHERE b.booking_status = 'Booked'
    AND s.show_date >= b.booking_datetime::DATE
GROUP BY
    CASE
        WHEN s.show_date - b.booking_datetime::DATE = 0
            THEN 'Same Day'
        WHEN s.show_date - b.booking_datetime::DATE BETWEEN 1 AND 3
            THEN '1-3 Days'
        WHEN s.show_date - b.booking_datetime::DATE BETWEEN 4 AND 7
            THEN '4-7 Days'
        WHEN s.show_date - b.booking_datetime::DATE BETWEEN 8 AND 15
            THEN '8-15 Days'
        ELSE 'More Than 15 Days'
    END
ORDER BY MIN(CASE
  WHEN s.show_date - b.booking_datetime::DATE = 0 THEN 1
  WHEN s.show_date - b.booking_datetime::DATE BETWEEN 1 AND 3 THEN 2
  WHEN s.show_date - b.booking_datetime::DATE BETWEEN 4 AND 7 THEN 3
  WHEN s.show_date - b.booking_datetime::DATE BETWEEN 8 AND 15 THEN 4
  ELSE 5 END);
